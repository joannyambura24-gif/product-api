from sqlmodel import SQLModel, Field
from typing import Optional


class Product(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    price: float
    quantity: int
    description: Optional[str] = None


class ProductCreate(SQLModel):
    name: str
    price: float
    quantity: int
    description: Optional[str] = None