from pydantic import BaseModel, Field, validator
from typing import Optional


class Supplier(BaseModel):
    id: int
    name: str
    email: str
    phone: str
    address: Optional[str] = None


class SupplierCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: str
    phone: str
    address: Optional[str] = None

    @validator("name")
    def validate_name(cls, value):
        if not value.strip():
            raise ValueError("Supplier name cannot be empty")
        return value

    @validator("email")
    def validate_email(cls, value):
        if "@" not in value:
            raise ValueError("Invalid email format")
        return value

    @validator("phone")
    def validate_phone(cls, value):
        if not value.isdigit():
            raise ValueError("Phone number must contain only digits")
        if len(value) < 10:
            raise ValueError("Phone number must be at least 10 digits")
        return value