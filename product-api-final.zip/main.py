from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from database import create_db_and_tables
from routers import products, supplier


app = FastAPI(
    title="Product API",
    version="1.0.0"
)


@app.on_event("startup")
def on_startup():
    create_db_and_tables()


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "Internal Server Error",
            "message": str(exc)
        }
    )


@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return JSONResponse(
        status_code=404,
        content={
            "success": False,
            "error": "Not Found",
            "message": "The requested resource was not found"
        }
    )


app.include_router(products.router)
app.include_router(supplier.router)


@app.get("/")
def home():
    return {
        "message": "Welcome to Product API"
    }