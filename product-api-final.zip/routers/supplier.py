from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from database import get_session
from models.supplier import Supplier, SupplierCreate

router = APIRouter(
    prefix="/suppliers",
    tags=["Suppliers"]
)


@router.get("/")
def get_suppliers(session: Session = Depends(get_session)):
    suppliers = session.exec(select(Supplier)).all()
    return suppliers


@router.get("/{supplier_id}")
def get_supplier(supplier_id: int, session: Session = Depends(get_session)):
    supplier = session.get(Supplier, supplier_id)

    if not supplier:
        raise HTTPException(
            status_code=404,
            detail="Supplier not found"
        )

    return supplier


@router.post("/")
def create_supplier(supplier: SupplierCreate, session: Session = Depends(get_session)):
    new_supplier = Supplier(
        name=supplier.name,
        email=supplier.email,
        phone=supplier.phone,
        address=supplier.address
    )

    session.add(new_supplier)
    session.commit()
    session.refresh(new_supplier)

    return new_supplier


@router.delete("/{supplier_id}")
def delete_supplier(supplier_id: int, session: Session = Depends(get_session)):
    supplier = session.get(Supplier, supplier_id)

    if not supplier:
        raise HTTPException(
            status_code=404,
            detail="Supplier not found"
        )

    session.delete(supplier)
    session.commit()

    return {
        "message": "Supplier deleted successfully"
    }