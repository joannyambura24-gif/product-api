from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from database import get_session
from models.product import Product, ProductCreate

router = APIRouter(
    prefix="/products",
    tags=["Products"]
)


@router.get("/")
def get_products(session: Session = Depends(get_session)):
    products = session.exec(select(Product)).all()
    return products


@router.get("/{product_id}")
def get_product(product_id: int, session: Session = Depends(get_session)):
    product = session.get(Product, product_id)

    if not product:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    return product


@router.post("/")
def create_product(product: ProductCreate, session: Session = Depends(get_session)):
    new_product = Product(
        name=product.name,
        price=product.price,
        quantity=product.quantity,
        description=product.description
    )

    session.add(new_product)
    session.commit()
    session.refresh(new_product)

    return new_product


@router.delete("/{product_id}")
def delete_product(product_id: int, session: Session = Depends(get_session)):
    product = session.get(Product, product_id)

    if not product:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    session.delete(product)
    session.commit()

    return {
        "message": "Product deleted successfully"
    }


@router.put("/bulk-update")
def bulk_update_products(
    products_data: list[ProductCreate],
    session: Session = Depends(get_session)
):
    updated_products = []

    for product_data in products_data:
        product = session.exec(
            select(Product).where(Product.name == product_data.name)
        ).first()

        if product:
            product.price = product_data.price
            product.quantity = product_data.quantity
            product.description = product_data.description

            session.add(product)
            updated_products.append(product)

    session.commit()

    return {
        "message": "Products updated successfully",
        "updated_products": updated_products
    }


@router.patch("/{product_id}/stock")
def adjust_stock(
    product_id: int,
    quantity_change: int,
    session: Session = Depends(get_session)
):
    product = session.get(Product, product_id)

    if not product:
        raise HTTPException(
            status_code=404,
            detail="Product not found"
        )

    new_quantity = product.quantity + quantity_change

    if new_quantity < 0:
        raise HTTPException(
            status_code=400,
            detail="Stock cannot be negative"
        )

    product.quantity = new_quantity

    session.add(product)
    session.commit()
    session.refresh(product)

    return {
        "message": "Stock adjusted successfully",
        "product": product
    }